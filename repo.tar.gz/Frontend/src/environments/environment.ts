export const environment = {
  production: true,
  apiUrl: 'https://proyecto-final-backend-c1et.onrender.com/api'
};
