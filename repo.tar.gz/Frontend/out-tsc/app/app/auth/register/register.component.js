import { __decorate } from "tslib";
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
let RegisterComponent = class RegisterComponent {
    auth;
    router;
    username = '';
    email = '';
    password = '';
    msg = '';
    loading = false;
    constructor(auth, router) {
        this.auth = auth;
        this.router = router;
    }
    submit() {
        if (!this.username) {
            this.msg = 'El usuario es obligatorio.';
            return;
        }
        if (!this.password || this.password.length < 6) {
            this.msg = 'La contraseña debe tener al menos 6 caracteres.';
            return;
        }
        this.loading = true;
        this.msg = 'Creando cuenta...';
        this.auth.register(this.username, this.email || null, this.password).subscribe({
            next: (data) => {
                this.msg = `Usuario creado: ${data?.username || this.username}. Continúa para crear tu primera wallet.`;
                // Marca un flag para mostrar CTA en Wallets tras el primer login
                try {
                    localStorage.setItem('ctaFirstWallet', '1');
                }
                catch { }
                // Envía al login con redirect a wallets
                setTimeout(() => this.router.navigate(['/auth/login'], { queryParams: { next: 'wallets', welcome: 1 } }), 500);
            },
            error: (e) => {
                this.loading = false;
                this.msg = 'Error al registrar: ' + ((e?.error && typeof e.error === 'object') ? JSON.stringify(e.error) : 'Intenta de nuevo.');
            }
        });
    }
};
RegisterComponent = __decorate([
    Component({
        selector: 'app-register',
        standalone: true,
        imports: [CommonModule, FormsModule, RouterLink],
        templateUrl: './register.component.html',
        styleUrls: ['./register.component.css']
    })
], RegisterComponent);
export { RegisterComponent };
