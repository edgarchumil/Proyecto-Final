import { __decorate } from "tslib";
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
let LoginComponent = class LoginComponent {
    auth;
    router;
    route;
    username = '';
    password = '';
    loading = false;
    error = '';
    nextRoute = '/dashboard';
    constructor(auth, router, route) {
        this.auth = auth;
        this.router = router;
        this.route = route;
        this.route.queryParams.subscribe(q => {
            const next = q['next'] || '/dashboard';
            // sanitiza: solo rutas internas conocidas
            this.nextRoute = next.startsWith('/') ? next : `/${next}`;
        });
    }
    submit() {
        if (!this.username || !this.password) {
            this.error = 'Completa usuario y contraseña.';
            return;
        }
        this.loading = true;
        this.error = '';
        this.auth.login(this.username, this.password).subscribe({
            next: () => this.router.navigate([this.nextRoute]),
            error: (e) => {
                this.loading = false;
                this.error = (e?.error && typeof e.error === 'object') ? JSON.stringify(e.error) : 'Login fallido';
            }
        });
    }
};
LoginComponent = __decorate([
    Component({
        selector: 'app-login',
        standalone: true,
        imports: [CommonModule, FormsModule, RouterLink],
        templateUrl: './login.component.html',
        styleUrls: ['./login.component.css']
    })
], LoginComponent);
export { LoginComponent };
