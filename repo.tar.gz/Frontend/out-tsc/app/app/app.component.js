import { __decorate } from "tslib";
import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { TopbarComponent } from './layout/topbar/topbar.component';
let AppComponent = class AppComponent {
    auth;
    router;
    onBeforeUnload = (e) => {
        // cierra sesión al cerrar/recargar la pestaña/ventana
        this.auth.silentLogout();
    };
    onPageHide = () => {
        // iOS/Safari/Firefox disparan pagehide al cerrar
        this.auth.silentLogout();
    };
    onStorage = (e) => {
        // si otra pestaña borra tokens, reflejar aquí
        if (e.storageArea === localStorage && (e.key === 'access' || e.key === 'refresh')) {
            if (!localStorage.getItem('access')) {
                this.auth.silentLogout();
                this.router.navigate(['/auth/login']);
            }
        }
    };
    constructor(auth, router) {
        this.auth = auth;
        this.router = router;
    }
    ngOnInit() {
        // 1) al entrar al sitio, siempre limpiar y exigir login
        this.auth.forceFreshLogin();
        this.router.navigate(['/auth/login']);
        // 2) listeners para cerrar sesión al cerrar/recargar
        window.addEventListener('beforeunload', this.onBeforeUnload);
        window.addEventListener('pagehide', this.onPageHide);
        // 3) sincronizar entre pestañas
        window.addEventListener('storage', this.onStorage);
    }
    ngOnDestroy() {
        window.removeEventListener('beforeunload', this.onBeforeUnload);
        window.removeEventListener('pagehide', this.onPageHide);
        window.removeEventListener('storage', this.onStorage);
    }
};
AppComponent = __decorate([
    Component({
        selector: 'app-root',
        standalone: true,
        imports: [RouterOutlet, TopbarComponent],
        templateUrl: './app.component.html',
        styleUrls: ['./app.component.css']
    })
], AppComponent);
export { AppComponent };
