import { __decorate } from "tslib";
import { Injectable } from '@angular/core';
let AuthGuard = class AuthGuard {
    router;
    constructor(router) {
        this.router = router;
    }
    canActivate = () => {
        const ok = !!localStorage.getItem('access');
        if (!ok) {
            this.router.navigate(['/auth/login']);
            return false;
        }
        return true;
    };
};
AuthGuard = __decorate([
    Injectable({ providedIn: 'root' })
], AuthGuard);
export { AuthGuard };
