import { __decorate } from "tslib";
import { Injectable } from '@angular/core';
import { BehaviorSubject, tap } from 'rxjs';
import { environment } from '../../environments/environment';
let AuthService = class AuthService {
    http;
    authStatus = new BehaviorSubject(!!localStorage.getItem('access'));
    /** Observable de estado de sesión */
    authStatus$ = this.authStatus.asObservable();
    constructor(http) {
        this.http = http;
    }
    // ---------- Sesión ----------
    isAuthenticated() { return !!localStorage.getItem('access'); }
    clearTokens() {
        localStorage.removeItem('access');
        localStorage.removeItem('refresh');
        this.authStatus.next(false);
    }
    /** Forzar login fresco al abrir la app (si así lo quieres) */
    forceFreshLogin() { this.clearTokens(); }
    /** Logout silencioso (para beforeunload/pagehide) */
    silentLogout() { this.clearTokens(); }
    logout() { this.clearTokens(); }
    // ---------- Endpoints ----------
    login(username, password) {
        return this.http
            .post(`${environment.apiUrl}/auth/token/`, { username, password })
            .pipe(tap(t => {
            localStorage.setItem('access', t.access);
            localStorage.setItem('refresh', t.refresh);
            this.authStatus.next(true);
        }));
    }
    register(username, email, password) {
        return this.http.post(`${environment.apiUrl}/users/register/`, { username, email, password });
    }
    me() {
        return this.http.get(`${environment.apiUrl}/users/me/`);
    }
    refreshToken() {
        const refresh = localStorage.getItem('refresh');
        return this.http
            .post(`${environment.apiUrl}/auth/token/refresh/`, { refresh })
            .pipe(tap(r => { if (r?.access)
            localStorage.setItem('access', r.access); }));
    }
};
AuthService = __decorate([
    Injectable({ providedIn: 'root' })
], AuthService);
export { AuthService };
