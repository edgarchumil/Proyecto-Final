import { __decorate } from "tslib";
import { Component } from '@angular/core';
import { CommonModule, NgFor, DatePipe, JsonPipe } from '@angular/common';
let AuditComponent = class AuditComponent {
    audit;
    logs = [];
    loading = false;
    error = null;
    constructor(audit) {
        this.audit = audit;
    }
    ngOnInit() {
        this.loading = true;
        this.error = null;
        this.audit.list().subscribe({
            next: data => { this.logs = data; this.loading = false; },
            error: () => { this.error = 'No se pudo cargar el audit log.'; this.loading = false; }
        });
    }
};
AuditComponent = __decorate([
    Component({
        selector: 'app-audit',
        standalone: true,
        imports: [CommonModule, NgFor, DatePipe, JsonPipe],
        templateUrl: './audit.component.html',
        styleUrls: ['./audit.component.css']
    })
], AuditComponent);
export { AuditComponent };
