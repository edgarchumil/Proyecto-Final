import { __decorate } from "tslib";
import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
let AuditService = class AuditService {
    http;
    base = `${environment.apiUrl}/audit-logs/`;
    constructor(http) {
        this.http = http;
    }
    list() {
        return this.http.get(this.base);
    }
};
AuditService = __decorate([
    Injectable({ providedIn: 'root' })
], AuditService);
export { AuditService };
