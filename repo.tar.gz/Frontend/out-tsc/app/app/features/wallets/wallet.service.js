import { __decorate } from "tslib";
import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
let WalletService = class WalletService {
    http;
    base = `${environment.apiUrl}/wallets/`;
    constructor(http) {
        this.http = http;
    }
    list() {
        return this.http.get(this.base);
    }
    create(name) {
        return this.http.post(this.base, { name });
    }
    remove(id) {
        return this.http.delete(`${this.base}${id}/`);
    }
};
WalletService = __decorate([
    Injectable({ providedIn: 'root' })
], WalletService);
export { WalletService };
