import { __decorate } from "tslib";
import { Injectable } from '@angular/core';
import { HttpParams } from '@angular/common/http';
import { environment } from '../../../environments/environment';
let TransactionsService = class TransactionsService {
    http;
    base = `${environment.apiUrl}/tx/`;
    constructor(http) {
        this.http = http;
    }
    list(filters) {
        let params = new HttpParams();
        if (filters?.status)
            params = params.set('status', filters.status);
        if (filters?.wallet)
            params = params.set('wallet', filters.wallet);
        return this.http.get(this.base, { params });
    }
    create(payload) {
        return this.http.post(this.base, payload);
    }
    confirm(id, block) {
        return this.http.post(`${this.base}${id}/confirm/`, { block });
    }
    fail(id) {
        return this.http.post(`${this.base}${id}/fail/`, {});
    }
};
TransactionsService = __decorate([
    Injectable({ providedIn: 'root' })
], TransactionsService);
export { TransactionsService };
