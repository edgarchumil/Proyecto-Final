import { __decorate } from "tslib";
import { Component } from '@angular/core';
import { CommonModule, NgFor, NgIf, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
let TxsComponent = class TxsComponent {
    route;
    txs;
    walletsApi;
    fromWalletId;
    fromPubKey;
    sub;
    wallets = [];
    transactions = [];
    loading = false;
    error = null;
    sending = false;
    success = null;
    form = {
        from_wallet: null,
        to_wallet: null,
        amount: 0,
        fee: 0.001,
    };
    statusFilter = 'ALL';
    walletFilter = null;
    constructor(route, txs, walletsApi) {
        this.route = route;
        this.txs = txs;
        this.walletsApi = walletsApi;
    }
    ngOnInit() {
        this.sub = this.route.queryParamMap.subscribe(params => {
            const f = params.get('from');
            const p = params.get('pub');
            this.fromWalletId = f ? Number(f) : undefined;
            this.fromPubKey = p || undefined;
            if (this.fromWalletId) {
                this.form.from_wallet = this.fromWalletId;
                this.walletFilter = this.fromWalletId;
            }
        });
        this.loadWallets();
        this.fetch();
    }
    ngOnDestroy() {
        this.sub?.unsubscribe();
    }
    loadWallets() {
        this.walletsApi.list().subscribe({
            next: (data) => {
                this.wallets = data;
                if (!this.form.from_wallet && this.wallets.length) {
                    this.form.from_wallet = this.wallets[0].id;
                }
            },
            error: () => this.error = 'No se pudo cargar tus wallets.'
        });
    }
    fetch() {
        this.loading = true;
        this.error = null;
        const filters = {};
        if (this.statusFilter !== 'ALL')
            filters.status = this.statusFilter;
        if (this.walletFilter)
            filters.wallet = this.walletFilter;
        this.txs.list(filters).subscribe({
            next: data => { this.transactions = data; this.loading = false; },
            error: () => { this.error = 'No se pudo cargar transacciones.'; this.loading = false; }
        });
    }
    create() {
        this.error = null;
        this.success = null;
        if (!this.form.from_wallet) {
            this.error = 'Selecciona la wallet emisora.';
            return;
        }
        const to = Number(this.form.to_wallet);
        if (!Number.isInteger(to) || to <= 0) {
            this.error = 'Ingresa un ID numérico válido para la wallet destino.';
            return;
        }
        if (to === this.form.from_wallet) {
            this.error = 'La wallet destino debe ser distinta a la emisora.';
            return;
        }
        const amount = Number(this.form.amount);
        if (!Number.isFinite(amount) || amount <= 0) {
            this.error = 'El monto debe ser mayor a cero.';
            return;
        }
        const fee = Number(this.form.fee);
        if (!Number.isFinite(fee) || fee < 0) {
            this.error = 'La comisión no puede ser negativa.';
            return;
        }
        this.form.to_wallet = to;
        this.form.amount = amount;
        this.form.fee = fee;
        this.sending = true;
        const payload = {
            from_wallet: this.form.from_wallet,
            to_wallet: to,
            amount,
            fee,
        };
        this.txs.create(payload).subscribe({
            next: (tx) => {
                this.form.to_wallet = null;
                this.form.amount = 0;
                this.form.fee = 0.001;
                this.success = tx;
                this.fetch();
                this.sending = false;
            },
            error: () => {
                this.error = 'No se pudo enviar la transacción.';
                this.sending = false;
            }
        });
    }
    applyFilters() { this.fetch(); }
    dismissSuccess() { this.success = null; }
};
TxsComponent = __decorate([
    Component({
        selector: 'app-txs',
        standalone: true,
        imports: [CommonModule, FormsModule, NgFor, NgIf, DatePipe],
        templateUrl: './txs.component.html',
        styleUrls: ['./txs.component.css']
    })
], TxsComponent);
export { TxsComponent };
