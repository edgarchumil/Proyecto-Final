import { __decorate } from "tslib";
import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
let BlocksService = class BlocksService {
    http;
    base = `${environment.apiUrl}/blocks/`;
    constructor(http) {
        this.http = http;
    }
    list() {
        return this.http.get(this.base);
    }
    create(payload) {
        return this.http.post(this.base, payload);
    }
};
BlocksService = __decorate([
    Injectable({ providedIn: 'root' })
], BlocksService);
export { BlocksService };
