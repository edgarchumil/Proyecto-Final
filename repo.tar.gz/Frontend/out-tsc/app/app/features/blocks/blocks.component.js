import { __decorate } from "tslib";
import { Component } from '@angular/core';
import { CommonModule, NgFor, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
let BlocksComponent = class BlocksComponent {
    service;
    blocks = [];
    loading = false;
    error = null;
    merkle = '';
    nonce = '';
    mining = false;
    constructor(service) {
        this.service = service;
    }
    ngOnInit() {
        this.refresh();
    }
    refresh() {
        this.loading = true;
        this.error = null;
        this.service.list().subscribe({
            next: (blocks) => {
                this.blocks = blocks;
                this.loading = false;
            },
            error: () => {
                this.error = 'No se pudo cargar la cadena de bloques.';
                this.loading = false;
            }
        });
    }
    mine() {
        if (!this.merkle.trim() || !this.nonce.trim()) {
            this.error = 'Ingresa merkle_root y nonce.';
            return;
        }
        this.error = null;
        this.mining = true;
        this.service.create({ merkle_root: this.merkle.trim(), nonce: this.nonce.trim() }).subscribe({
            next: () => {
                this.merkle = '';
                this.nonce = '';
                this.mining = false;
                this.refresh();
            },
            error: () => {
                this.error = 'No se pudo minar el bloque.';
                this.mining = false;
            }
        });
    }
    randomFill() {
        if (!this.merkle)
            this.merkle = cryptoRandomHex(64);
        if (!this.nonce)
            this.nonce = cryptoRandomHex(16);
    }
};
BlocksComponent = __decorate([
    Component({
        selector: 'app-blocks',
        standalone: true,
        imports: [CommonModule, NgFor, FormsModule, DatePipe],
        templateUrl: './blocks.component.html',
        styleUrls: ['./blocks.component.css']
    })
], BlocksComponent);
export { BlocksComponent };
function cryptoRandomHex(len) {
    const bytes = new Uint8Array(len / 2);
    if (typeof crypto !== 'undefined' && crypto.getRandomValues) {
        crypto.getRandomValues(bytes);
    }
    else {
        for (let i = 0; i < bytes.length; i++)
            bytes[i] = Math.floor(Math.random() * 256);
    }
    return Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('');
}
