import { __decorate } from "tslib";
import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
let PriceService = class PriceService {
    http;
    base = `${environment.apiUrl}/prices/`;
    constructor(http) {
        this.http = http;
    }
    list() {
        return this.http.get(this.base);
    }
    latest() {
        return this.http.get(`${this.base}latest/`);
    }
    create(payload) {
        return this.http.post(this.base, payload);
    }
};
PriceService = __decorate([
    Injectable({ providedIn: 'root' })
], PriceService);
export { PriceService };
