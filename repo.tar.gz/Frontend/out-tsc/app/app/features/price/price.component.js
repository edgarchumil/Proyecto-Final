import { __decorate } from "tslib";
import { Component } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Chart, LineController, LineElement, PointElement, LinearScale, Tooltip, Legend, CategoryScale } from 'chart.js';
Chart.register(LineController, LineElement, PointElement, LinearScale, CategoryScale, Tooltip, Legend);
let PriceComponent = class PriceComponent {
    price;
    ticks = [];
    loading = false;
    error = null;
    chart;
    form = {
        price_usd: 1,
        ts: new Date().toISOString().slice(0, 16),
    };
    constructor(price) {
        this.price = price;
    }
    ngAfterViewInit() {
        this.fetch();
    }
    ngOnDestroy() { this.chart?.destroy(); }
    fetch() {
        this.loading = true;
        this.error = null;
        this.price.list().subscribe({
            next: data => {
                this.ticks = data;
                this.loading = false;
                this.renderChart();
            },
            error: () => {
                this.error = 'No se pudo cargar el histórico de precios.';
                this.loading = false;
            }
        });
    }
    addTick() {
        if (!this.form.price_usd || this.form.price_usd <= 0) {
            this.error = 'Ingresa un precio válido.';
            return;
        }
        this.error = null;
        const payload = {
            ts: new Date(this.form.ts).toISOString(),
            price_usd: Number(this.form.price_usd),
        };
        this.price.create(payload).subscribe({
            next: tick => {
                this.ticks = [tick, ...this.ticks];
                this.renderChart();
                this.form.ts = new Date().toISOString().slice(0, 16);
            },
            error: () => this.error = 'No se pudo registrar el precio.'
        });
    }
    renderChart() {
        const canvas = document.getElementById('priceChart');
        if (!canvas)
            return;
        const ctx = canvas.getContext('2d');
        if (!ctx)
            return;
        const sorted = [...this.ticks].sort((a, b) => new Date(a.ts).getTime() - new Date(b.ts).getTime());
        const labels = sorted.map(t => new Date(t.ts).toLocaleString());
        const data = sorted.map(t => Number(t.price_usd));
        this.chart?.destroy();
        this.chart = new Chart(ctx, {
            type: 'line',
            data: {
                labels,
                datasets: [{
                        label: 'SIM / USD',
                        data,
                        borderColor: '#38bdf8',
                        backgroundColor: 'rgba(56,189,248,0.2)',
                        tension: 0.3,
                        fill: true
                    }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: true },
                    tooltip: { callbacks: { label: ctx => ` ${ctx.parsed.y?.toFixed(4)} USD` } }
                },
                scales: {
                    y: { beginAtZero: false }
                }
            }
        });
    }
};
PriceComponent = __decorate([
    Component({
        selector: 'app-price',
        standalone: true,
        imports: [CommonModule, FormsModule, DatePipe],
        templateUrl: './price.component.html',
        styleUrls: ['./price.component.css']
    })
], PriceComponent);
export { PriceComponent };
