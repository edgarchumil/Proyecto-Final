import { __decorate } from "tslib";
import { Component } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { CommonModule } from '@angular/common';
let TopbarComponent = class TopbarComponent {
    auth;
    router;
    isLoggedIn = false;
    open = false;
    sub;
    constructor(auth, router) {
        this.auth = auth;
        this.router = router;
    }
    ngOnInit() {
        this.isLoggedIn = this.auth.isAuthenticated();
        this.sub = this.auth.authStatus$.subscribe((v) => this.isLoggedIn = v);
        this.router.events.subscribe(() => this.open = false);
    }
    toggle() { this.open = !this.open; }
    close() { this.open = false; }
    logout() {
        this.auth.logout();
        this.router.navigate(['/auth/login']);
        this.open = false;
    }
    ngOnDestroy() { this.sub?.unsubscribe(); }
};
TopbarComponent = __decorate([
    Component({
        selector: 'app-topbar',
        standalone: true,
        imports: [CommonModule, RouterLink, RouterLinkActive],
        templateUrl: './topbar.component.html',
        styleUrls: ['./topbar.component.css']
    })
], TopbarComponent);
export { TopbarComponent };
