import { __decorate } from "tslib";
// src/app/dashboard/dashboard.component.ts
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { forkJoin, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Chart, LineController, LineElement, PointElement, LinearScale, Title, CategoryScale, Filler, Legend, } from 'chart.js';
Chart.register(LineController, LineElement, PointElement, LinearScale, Title, CategoryScale, Filler, Legend);
let DashboardComponent = class DashboardComponent {
    walletsApi;
    txsApi;
    blocksApi;
    priceApi;
    auditApi;
    chart;
    metricsSub;
    walletsCount;
    txCount;
    blockCount;
    auditCount;
    lastPrice = null;
    confirmedCount = 0;
    pendingCount = 0;
    walletSummaries = [];
    totalBalance = 0;
    recentTransactions = [];
    priceSeries = [];
    loadingMetrics = false;
    constructor(walletsApi, txsApi, blocksApi, priceApi, auditApi) {
        this.walletsApi = walletsApi;
        this.txsApi = txsApi;
        this.blocksApi = blocksApi;
        this.priceApi = priceApi;
        this.auditApi = auditApi;
    }
    ngOnInit() {
        this.loadMetrics();
    }
    ngAfterViewInit() {
        this.renderChart();
    }
    ngOnDestroy() {
        this.chart?.destroy();
        this.metricsSub?.unsubscribe();
    }
    loadMetrics() {
        this.loadingMetrics = true;
        this.metricsSub?.unsubscribe();
        this.metricsSub = forkJoin({
            wallets: this.walletsApi.list().pipe(catchError(() => of([]))),
            txs: this.txsApi.list().pipe(catchError(() => of([]))),
            blocks: this.blocksApi.list().pipe(catchError(() => of([]))),
            prices: this.priceApi.list().pipe(catchError(() => of([]))),
            audit: this.auditApi.list().pipe(catchError(() => of([])))
        }).subscribe({
            next: ({ wallets, txs, blocks, prices, audit }) => {
                this.walletsCount = wallets.length;
                this.txsCountFromData(txs);
                this.blockCount = blocks.length;
                this.auditCount = audit.length;
                this.walletSummaries = this.buildWalletSummaries(wallets, txs);
                this.totalBalance = this.walletSummaries.reduce((acc, item) => acc + item.balance, 0);
                this.recentTransactions = [...txs]
                    .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
                    .slice(0, 6);
                this.priceSeries = [...prices]
                    .sort((a, b) => new Date(a.ts).getTime() - new Date(b.ts).getTime())
                    .slice(-20);
                const latest = prices[0];
                this.lastPrice = latest ? Number(latest.price_usd) : null;
                this.loadingMetrics = false;
                this.renderChart();
            },
            error: () => {
                this.loadingMetrics = false;
            }
        });
    }
    buildWalletSummaries(wallets, txs) {
        const balances = new Map();
        wallets.forEach(w => balances.set(w.id, 0));
        this.confirmedCount = 0;
        this.pendingCount = 0;
        txs.forEach(tx => {
            if (tx.status === 'CONFIRMED') {
                this.confirmedCount += 1;
                const fromBalance = balances.get(tx.from_wallet);
                if (fromBalance !== undefined) {
                    balances.set(tx.from_wallet, fromBalance - (Number(tx.amount) + Number(tx.fee)));
                }
                const toBalance = balances.get(tx.to_wallet);
                if (toBalance !== undefined) {
                    balances.set(tx.to_wallet, toBalance + Number(tx.amount));
                }
            }
            else if (tx.status === 'PENDING') {
                this.pendingCount += 1;
            }
        });
        return wallets.map(wallet => ({
            wallet,
            balance: balances.get(wallet.id) ?? 0
        }));
    }
    txsCountFromData(txs) {
        this.txCount = txs.length;
    }
    renderChart() {
        const canvas = document.getElementById('activityChart');
        if (!canvas) {
            return;
        }
        const ctx = canvas.getContext('2d');
        if (!ctx) {
            return;
        }
        if (!this.priceSeries.length) {
            this.chart?.destroy();
            return;
        }
        const labels = this.priceSeries.map(t => new Date(t.ts).toLocaleString());
        const data = this.priceSeries.map(t => Number(t.price_usd));
        this.chart?.destroy();
        this.chart = new Chart(ctx, {
            type: 'line',
            data: {
                labels,
                datasets: [{
                        label: 'SIM / USD',
                        data,
                        borderColor: '#38bdf8',
                        backgroundColor: 'rgba(56,189,248,0.2)',
                        tension: 0.3,
                        fill: true
                    }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: true }
                },
                scales: {
                    y: { beginAtZero: false }
                }
            }
        });
    }
};
DashboardComponent = __decorate([
    Component({
        selector: 'app-dashboard',
        standalone: true,
        imports: [CommonModule, RouterLink],
        templateUrl: './dashboard.component.html',
        styleUrls: ['./dashboard.component.css']
    })
], DashboardComponent);
export { DashboardComponent };
