import os, hashlib
from decimal import Decimal, ROUND_HALF_UP
from django.db import transaction as dbtx
from django.db.models import Max
from rest_framework import serializers
from .models import Transaction, TradeRequest
from wallets.models import Wallet
from blocks.models import Block
from .utils import wallet_available_balance

TWOPLACES = Decimal('0.01')


def _compute_tx_hash(from_id: int, to_id: int, amount: Decimal, fee: Decimal, salt: bytes) -> str:
    base = f'{from_id}:{to_id}:{amount}:{fee}:{salt.hex()}'.encode('utf-8')
    return hashlib.sha256(base).hexdigest()

class TransactionCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Transaction
        fields = ('from_wallet', 'to_wallet', 'amount', 'fee', 'currency')  # el servidor genera tx_hash y status
        extra_kwargs = {
            'fee': {'required': False, 'default': Decimal('0')},
            'currency': {'required': False, 'default': Transaction.CURRENCY_SIM}
        }

    def validate(self, data):
        from_w: Wallet = data['from_wallet']
        to_w: Wallet = data['to_wallet']

        if from_w_id := getattr(from_w, 'id', None) == getattr(to_w, 'id', None):
            raise serializers.ValidationError('from_wallet y to_wallet deben ser distintos.')

        amount = data.get('amount')
        fee = data.get('fee', Decimal('0'))
        currency = (data.get('currency') or Transaction.CURRENCY_SIM).upper()
        valid_currencies = {choice[0] for choice in Transaction.CURRENCY_CHOICES}
        if currency not in valid_currencies:
            raise serializers.ValidationError({'currency': 'Moneda inválida.'})

        if amount is None:
            raise serializers.ValidationError('amount es requerido.')
        if amount <= 0:
            raise serializers.ValidationError('amount debe ser > 0.')

        if fee < 0:
            raise serializers.ValidationError('fee no puede ser negativa.')

        data['amount'] = Decimal(str(amount)).quantize(TWOPLACES, rounding=ROUND_HALF_UP)
        data['fee'] = Decimal(str(fee)).quantize(TWOPLACES, rounding=ROUND_HALF_UP)
        data['currency'] = currency

        if getattr(from_w.user, 'username', '') == 'market':
            return data

        available = self._available_balance(from_w.id, currency)
        total_debit = data['amount'] + data['fee']
        if total_debit > available:
            raise serializers.ValidationError({'detail': 'Fondos insuficientes para completar la transacción.'})

        # Opcional: si quieres impedir enviar a wallets de otros usuarios, descomenta:
        # if from_w.user_id != self.context["request"].user.id:
        #     raise serializers.ValidationError("Solo puedes emitir desde tus propias wallets.")

        return data

    def _available_balance(self, wallet_id: int, currency: str) -> Decimal:
        return wallet_available_balance(wallet_id, currency)

    @dbtx.atomic
    def create(self, validated_data):
        salt = os.urandom(16)
        txh = _compute_tx_hash(
            validated_data['from_wallet'].id,
            validated_data['to_wallet'].id,
            validated_data['amount'],
            validated_data['fee'],
            salt
        )
        # status arranca en PENDING; block = None
        return Transaction.objects.create(tx_hash=txh, **validated_data)

class TransactionSerializer(serializers.ModelSerializer):
    from_wallet_name = serializers.CharField(source='from_wallet.name', read_only=True)
    to_wallet_name   = serializers.CharField(source='to_wallet.name', read_only=True)
    from_user = serializers.IntegerField(source='from_wallet.user.id', read_only=True)
    from_username = serializers.CharField(source='from_wallet.user.username', read_only=True)
    to_user = serializers.IntegerField(source='to_wallet.user.id', read_only=True)
    to_username = serializers.CharField(source='to_wallet.user.username', read_only=True)

    class Meta:
        model = Transaction
        fields = (
            'id',
            'from_wallet', 'from_wallet_name', 'from_user', 'from_username',
            'to_wallet', 'to_wallet_name', 'to_user', 'to_username',
            'amount', 'fee', 'currency', 'tx_hash', 'status', 'block', 'created_at'
        )
        read_only_fields = ('id', 'tx_hash', 'status', 'block', 'created_at')

class TransactionConfirmSerializer(serializers.ModelSerializer):
    """Solo cambia status→CONFIRMED. Si no se envía block, se crea uno nuevo."""
    block = serializers.PrimaryKeyRelatedField(queryset=Block.objects.all(), required=False, allow_null=True)

    class Meta:
        model = Transaction
        fields = ('block',)

    @dbtx.atomic
    def update(self, instance: Transaction, validated_data):
        block: Block | None = validated_data.get('block')
        if block is None:
            from django.db.models import Max
            last_height = Block.objects.aggregate(m=Max('height'))['m']
            next_height = 0 if last_height is None else last_height + 1
            if last_height is None:
                prev_hash = '0' * 64
            else:
                prev_block = Block.objects.get(height=last_height)
                prev_hash = prev_block.hash
            merkle = (instance.tx_hash or '').ljust(64, '0')[:64]
            nonce = os.urandom(8).hex()
            block = Block.objects.create(
                height=next_height,
                prev_hash=prev_hash,
                merkle_root=merkle,
                nonce=nonce
            )
        instance.block = block
        instance.status = Transaction.STATUS_CONFIRMED
        instance.save(update_fields=['block', 'status'])
        return instance

class TransactionFailSerializer(serializers.ModelSerializer):
    class Meta:
        model = Transaction
        fields = ()  # no llega nada, solo cambiamos estado

    @dbtx.atomic
    def update(self, instance: Transaction, validated_data):
        instance.status = Transaction.STATUS_FAILED
        instance.save(update_fields=['status'])
        return instance


class TradeRequestSerializer(serializers.ModelSerializer):
    requester_username = serializers.CharField(source='requester.username', read_only=True)
    counterparty_username = serializers.CharField(source='counterparty.username', read_only=True)

    class Meta:
        model = TradeRequest
        fields = (
            'id', 'token', 'side', 'amount', 'fee', 'currency', 'status', 'created_at',
            'requester', 'requester_username', 'counterparty', 'counterparty_username'
        )
        read_only_fields = ('id', 'token', 'status', 'created_at', 'requester')

class TradeRequestCreateSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True)

    class Meta:
        model = TradeRequest
        fields = ('counterparty', 'side', 'amount', 'fee', 'currency', 'password')
        extra_kwargs = {
            'fee': {'required': False, 'default': Decimal('0')},
            'currency': {'required': False, 'default': Transaction.CURRENCY_SIM},
            'password': {'write_only': True}
        }

    def validate(self, attrs):
        password = attrs.get('password')
        if not password:
            raise serializers.ValidationError({'password': 'Debes ingresar tu contraseña.'})
        currency = (attrs.get('currency') or Transaction.CURRENCY_SIM).upper()
        valid_currencies = {choice[0] for choice in Transaction.CURRENCY_CHOICES}
        if currency not in valid_currencies:
            raise serializers.ValidationError({'currency': 'Moneda inválida.'})
        attrs['currency'] = currency
        request = self.context.get('request')
        if not request or not getattr(request, 'user', None):
            raise serializers.ValidationError({'password': 'No se pudo validar la contraseña.'})
        if not request.user.check_password(password):
            raise serializers.ValidationError({'password': 'Contraseña incorrecta.'})
        return attrs

    def create(self, validated_data):
        import secrets
        requester = self.context['request'].user
        validated_data.pop('password', None)
        token = secrets.token_hex(16)
        amount = Decimal(str(validated_data.get('amount', Decimal('0')))).quantize(TWOPLACES, rounding=ROUND_HALF_UP)
        fee = Decimal(str(validated_data.get('fee', Decimal('0')))).quantize(TWOPLACES, rounding=ROUND_HALF_UP)
        validated_data['amount'] = amount
        validated_data['fee'] = fee
        return TradeRequest.objects.create(requester=requester, token=token, **validated_data)
